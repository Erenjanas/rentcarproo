const { verifyToken } = require('../utils/security');
const { get } = require('../db/database');

async function auth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Oturum gerekli' });
    const decoded = verifyToken(token);
    const user = await get('SELECT id, name, email, role, status FROM users WHERE id = ?', [decoded.id]);
    if (!user || user.status !== 'active') return res.status(401).json({ error: 'Geçersiz kullanıcı' });
    req.user = user;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Geçersiz token' });
  }
}

function adminOnly(req, res, next) {
  if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admin yetkisi gerekli' });
  next();
}

module.exports = { auth, adminOnly };
