const router = require('express').Router();
const ctrl = require('../controllers/reservationController');
const { auth, adminOnly } = require('../middleware/auth');
router.get('/', auth, adminOnly, ctrl.listReservations);
router.post('/', ctrl.createReservation);
router.put('/:id', auth, adminOnly, ctrl.updateReservation);
router.delete('/:id', auth, adminOnly, ctrl.deleteReservation);
module.exports = router;
